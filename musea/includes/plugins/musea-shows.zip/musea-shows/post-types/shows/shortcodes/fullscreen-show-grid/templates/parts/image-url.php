<div class="eltdf-image-url-holder-inner">
	<div class="eltdf-image-url" <?php musea_elated_inline_style($this_object->getItemBackgroundImage())?>></div>
</div>


