<?php

if(musea_shows_is_tickera_installed()){

    require_once 'event-list.php';
    require_once 'helper-functions.php';

}