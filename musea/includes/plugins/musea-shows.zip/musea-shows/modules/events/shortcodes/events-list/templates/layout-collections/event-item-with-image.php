<div class="eltdf-event-list-item eltdf-item-space">
    <div class="eltdf-eli-image-holder">
        <?php echo musea_shows_get_module_shortcode_template_part('events', 'events-list', 'parts/image', '', $params); ?>
        <?php echo musea_shows_get_module_shortcode_template_part('events', 'events-list', 'parts/date-separated', '', $params); ?>
    </div>
    <div class="eltdf-eli-title-holder">
        <?php echo musea_shows_get_module_shortcode_template_part('events', 'events-list', 'parts/title', '', $params); ?>
        <?php echo musea_shows_get_module_shortcode_template_part('events', 'events-list', 'parts/subtitle', '', $params); ?>
    </div>
    <div class="eltdf-eli-read-more-holder clearfix">
        <?php echo musea_shows_get_module_shortcode_template_part('events', 'events-list', 'parts/read-more', '', $params); ?>
    </div>
</div>
