<<?php echo esc_attr($title_tag); ?> itemprop="name" class="eltdf-eli-title entry-title">
    <?php echo esc_attr(get_the_title()); ?>
</<?php echo esc_attr($title_tag); ?>>
