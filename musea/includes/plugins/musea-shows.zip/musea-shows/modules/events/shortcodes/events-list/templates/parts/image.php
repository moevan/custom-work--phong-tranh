<div class="eltdf-eli-image">
	<?php the_post_thumbnail('full') ?>
</div>
