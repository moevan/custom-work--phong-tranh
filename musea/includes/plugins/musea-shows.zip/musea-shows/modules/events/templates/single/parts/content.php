<div class="eltdf-single-event-content">
    <?php the_content(); ?>
</div>