<div class="eltdf-event-singe-holder eltdf-grid-row">

    <div class="eltdf-grid-col-4">
        <div class="eltdf-event-single-image-holder">
            <?php musea_shows_get_module_template_part('events', '/single/parts/image'); ?>
        </div>
    </div>
    <div class="eltdf-grid-col-8">
        <?php musea_shows_get_module_template_part('events', '/single/parts/tickets'); ?>
    </div>
    <div class="eltdf-grid-col-12">
        <?php musea_shows_get_module_template_part('events', '/single/parts/content'); ?>
    </div>
</div>