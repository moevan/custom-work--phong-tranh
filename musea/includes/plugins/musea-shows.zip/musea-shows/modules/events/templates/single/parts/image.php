<div class="eltdf-event-single-image">
    <?php the_post_thumbnail('full'); ?>
</div>
