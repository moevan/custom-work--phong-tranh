<div class="eltdf-image-marquee-holder">
    <div class="eltdf-image-marquee">
        <div class="eltdf-image eltdf-original">
            <img src="<?php echo wp_get_attachment_url($image); ?>" alt="<?php echo get_the_title($image) ?>" />
        </div>
        <div class="eltdf-image eltdf-aux">
            <img src="<?php echo wp_get_attachment_url($image); ?>" alt="<?php echo get_the_title($image) ?>" />
        </div>
    </div>
</div>