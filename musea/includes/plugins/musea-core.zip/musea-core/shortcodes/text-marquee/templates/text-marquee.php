<div class="eltdf-text-marquee <?php echo esc_attr( $holder_classes ); ?>" <?php echo musea_elated_inline_style( $text_styles ); ?> <?php echo musea_elated_get_inline_attrs( $text_data ); ?>>
	<span class="eltdf-marquee-element eltdf-original-text"><?php echo esc_html( $text ) ?></span>
	<span class="eltdf-marquee-element eltdf-aux-text"><?php echo esc_html( $text ) ?></span>
</div>  