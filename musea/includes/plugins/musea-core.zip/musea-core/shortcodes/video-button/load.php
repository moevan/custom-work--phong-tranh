<?php

include_once MUSEA_CORE_SHORTCODES_PATH . '/video-button/functions.php';
include_once MUSEA_CORE_SHORTCODES_PATH . '/video-button/video-button.php';